<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">


	<title>PetShop - <?= $page_title; ?></title>

	<!-- Bootstrap core CSS -->
	<link href="<?= base_url("assets/customer/vendor/bootstrap/css/bootstrap.min.css") ?>" rel="stylesheet">

	<!-- Custom styles for this template -->
	<link href="<?= base_url("assets/customer/css/shop-homepage.css") ?>" rel="stylesheet">

	<!-- Font awesome -->
	<link href="<?= base_url("assets/customer/vendor/fontawesome-free/css/all.min.css") ?>" rel="stylesheet" type="text/css">

</head>
