<div class="card shadow border-0">
    <div class="card-body">
        <ul class="list-group">
            <li class="list-group-item"><a href="<?= base_url("home") ?>">Beranda</a></li>
            <li class="list-group-item"><a href="">Keranjang Belanja</a></li>
            <li class="list-group-item"><a href="<?= base_url("grooming") ?>">Grooming</a></li>
            <li class="list-group-item"><a href="<?= base_url("profile") ?>">Profile Saya</a></li>
            <li class="list-group-item"><a href="<?= base_url("logout") ?>" class="text-danger">Logout</a></li>
        </ul>
    </div>
</div>