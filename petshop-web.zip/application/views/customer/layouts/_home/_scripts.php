	<!-- Bootstrap core JavaScript-->
	<script src="<?= base_url("assets/customer/vendor/jquery/jquery.min.js") ?>"></script>
	<script src="<?= base_url("assets/customer/vendor/bootstrap/js/bootstrap.bundle.min.js") ?>"></script>

	<!-- Core plugin JavaScript-->
	<script src="<?= base_url("assets/customer/vendor/jquery-easing/jquery.easing.min.js") ?>"></script>

	<!-- Custom scripts for all pages-->
	<script src="<?= base_url("assets/customer/js/sb-admin-2.min.js") ?>"></script>
	<!-- Page level plugins -->
	<script src="<?= base_url("assets/customer/vendor/datatables/jquery.dataTables.min.js") ?>"></script>
	<script src="<?= base_url("assets/customer/vendor/datatables/dataTables.bootstrap4.min.js") ?>"></script>

	<!-- Page level custom scripts -->
	<script src="<?= base_url("assets/customer/js/demo/datatables-demo.js") ?>"></script>
	<script src="<?= base_url("assets/sweet-alert/sweetalert2.all.min.js") ?>"></script>
	<script src="<?= base_url("assets/customer/js/app.js") ?>"></script>
	<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
	<script>
		$(document).ready(function() {
			$('#summernote').summernote();
		});
	</script>