<!-- Bootstrap core JavaScript -->
<script src="<?= base_url("assets/customer/vendor/jquery/jquery.min.js") ?>"></script>
<script src="<?= base_url("assets/customer/vendor/bootstrap/js/bootstrap.bundle.min.js") ?>"></script>
<script src="<?= base_url("assets/sweet-alert/sweetalert2.all.min.js") ?>"></script>