<!-- General JS Scripts -->
<script src="<?= base_url("assets/admin/modules/jquery.min.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/popper.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/tooltip.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/bootstrap/js/bootstrap.min.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/nicescroll/jquery.nicescroll.min.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/moment.min.js") ?>"></script>
<script src="<?= base_url("assets/admin/js/stisla.js") ?>"></script>

<!-- JS Libraies -->
<script src="<?= base_url("assets/admin/modules/simple-weather/jquery.simpleWeather.min.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/chart.min.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/jqvmap/dist/jquery.vmap.min.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/jqvmap/dist/maps/jquery.vmap.world.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/summernote/summernote-bs4.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/chocolat/dist/js/jquery.chocolat.min.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/datatables/datatables.min.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/datatables/Select-1.2.4/js/dataTables.select.min.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/jquery-ui/jquery-ui.min.js") ?>"></script>
<script src="<?= base_url("assets/admin/modules/select2/dist/js/select2.full.min.js") ?>"></script>
<!-- Sweet alert -->
<!-- JS Libraies -->
<script src="<?= base_url("assets/admin/modules/sweetalert/sweetalert.min.js") ?>"></script>
<script src="<?= base_url("assets/admin/js/page/modules-sweetalert.js") ?>"></script>
<!-- Page Specific JS File -->
<script src="<?= base_url("assets/admin/js/page/index-0.js") ?>"></script>
<script src="<?= base_url("assets/admin/js/page/modules-datatables.js") ?>"></script>
<script src="<?= base_url("assets/admin/js/page/forms-advanced-forms.js") ?>"></script>

<!-- Template JS File -->
<script src="<?= base_url("assets/admin/js/scripts.js") ?>"></script>
<script src="<?= base_url("assets/admin/js/custom.js") ?>"></script>