<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; <?= date('Y') ?> - <a href="<?= base_url("/") ?>">Tegal Petshop</a>
    </div>
    <div class="footer-right">

    </div>
</footer>