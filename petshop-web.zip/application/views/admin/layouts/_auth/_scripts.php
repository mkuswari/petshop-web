    <!-- General JS Scripts -->
    <script src="<?= base_url("assets/admin/modules/jquery.min.js") ?>"></script>
    <script src="<?= base_url("assets/admin/modules/popper.js") ?>"></script>
    <script src="<?= base_url("assets/admin/modules/tooltip.js") ?>"></script>
    <script src="<?= base_url("assets/admin/modules/bootstrap/js/bootstrap.min.js") ?>"></script>
    <script src="<?= base_url("assets/admin/modules/nicescroll/jquery.nicescroll.min.js") ?>"></script>
    <script src="<?= base_url("assets/admin/modules/moment.min.js") ?>"></script>
    <script src="<?= base_url("assets/admin/js/stisla.js") ?>"></script>

    <!-- JS Libraies -->

    <!-- Page Specific JS File -->

    <!-- Template JS File -->
    <script src="<?= base_url("assets/admin/js/scripts.js") ?>"></script>
    <script src="<?= base_url("assets/admin/js/custom.js") ?>"></script>